Copy ASSETS to /utils
Copy data, train and eval files to semantic segmentation